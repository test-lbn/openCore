-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-01-2019 a las 18:34:57
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `opencore`
--
CREATE DATABASE IF NOT EXISTS `opencore` DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci;
USE `opencore`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `core_permisos`
--

DROP TABLE IF EXISTS `core_permisos`;
CREATE TABLE `core_permisos` (
  `id` int(11) NOT NULL,
  `id_rol` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_programa_opcion` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `core_permisos`
--

INSERT INTO `core_permisos` (`id`, `id_rol`, `id_programa_opcion`) VALUES
(1, '1', '1'),
(2, '1', '2'),
(3, '1', '3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `core_programas`
--

DROP TABLE IF EXISTS `core_programas`;
CREATE TABLE `core_programas` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_menu` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_submenu` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `autenticado` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `core_programas`
--

INSERT INTO `core_programas` (`id`, `descripcion`, `id_menu`, `id_submenu`, `autenticado`, `programa`) VALUES
(1, 'iniciar sesion', '1', '2', 'N', 'LOGIN'),
(2, 'home', '1', '2', 'S', 'INICIO'),
(3, 'programas', '1', '2', 'S', 'PROGRAMA'),
(4, 'usuarios', '1', '2', 'S', 'USUARIO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `core_programas_opciones`
--

DROP TABLE IF EXISTS `core_programas_opciones`;
CREATE TABLE `core_programas_opciones` (
  `id` int(11) NOT NULL,
  `id_programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `opcion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `core_programas_opciones`
--

INSERT INTO `core_programas_opciones` (`id`, `id_programa`, `opcion`, `descripcion`) VALUES
(1, '2', 'A', 'Acceso'),
(2, '3', 'A', 'Acceso'),
(3, '4', 'A', 'Acceso');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `core_roles`
--

DROP TABLE IF EXISTS `core_roles`;
CREATE TABLE `core_roles` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `horas_descanso` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `core_roles`
--

INSERT INTO `core_roles` (`id`, `nombre`, `horas_descanso`) VALUES
(1, 'ADMINISTRADOR', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `core_token`
--

DROP TABLE IF EXISTS `core_token`;
CREATE TABLE `core_token` (
  `id` int(11) NOT NULL,
  `id_usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `dominio` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `token` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `vigencia` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_hora` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `core_token`
--

INSERT INTO `core_token` (`id`, `id_usuario`, `dominio`, `token`, `vigencia`, `fecha_hora`) VALUES
(1, '1', 'localhost', '9d5712112f8cb8e3dabc8efed10b5c39bef18228', '2019-01-03', '2019-01-03 12:18:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `core_usuarios`
--

DROP TABLE IF EXISTS `core_usuarios`;
CREATE TABLE `core_usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `usr_pass` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nit` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `sitio_web` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `f_expira_p` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `core_usuarios`
--

INSERT INTO `core_usuarios` (`id`, `usuario`, `usr_pass`, `nombre`, `nit`, `sitio_web`, `estado`, `apellidos`, `correo`, `f_expira_p`) VALUES
(1, 'sistem04', 'bb5d45dc845c0f46a0b37b086c20e9b0b99ada1d', 'Brian', '1047971220', '', 'A', 'Rodriguez', 'brian.alber@hotmail.com', '2018-12-18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `core_usuarios_roles`
--

DROP TABLE IF EXISTS `core_usuarios_roles`;
CREATE TABLE `core_usuarios_roles` (
  `id` int(11) NOT NULL,
  `id_usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_rol` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `core_usuarios_roles`
--

INSERT INTO `core_usuarios_roles` (`id`, `id_usuario`, `id_rol`) VALUES
(1, '1', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupos`
--

DROP TABLE IF EXISTS `grupos`;
CREATE TABLE `grupos` (
  `id` int(11) NOT NULL,
  `grupo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nota` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `grupos`
--

INSERT INTO `grupos` (`id`, `grupo`, `nota`, `estado`) VALUES
(1, '1', 'Prueba de Grupo', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupos_usuario`
--

DROP TABLE IF EXISTS `grupos_usuario`;
CREATE TABLE `grupos_usuario` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `grupo` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `grupos_usuario`
--

INSERT INTO `grupos_usuario` (`id`, `usuario`, `grupo`) VALUES
(1, 'sistem04', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulo`
--

DROP TABLE IF EXISTS `modulo`;
CREATE TABLE `modulo` (
  `id` int(11) NOT NULL,
  `id_sub` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cod_mod` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cod_sub` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `icon_mod` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `des_mod` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `orden` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `modulo`
--

INSERT INTO `modulo` (`id`, `id_sub`, `cod_mod`, `cod_sub`, `icon_mod`, `des_mod`, `orden`) VALUES
(1, '1', '1', '1', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nue_programa`
--

DROP TABLE IF EXISTS `nue_programa`;
CREATE TABLE `nue_programa` (
  `id` int(11) NOT NULL,
  `cod_mod` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cod_sub` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `f_ingreso` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `f_modifica` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nota_prog` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nue_mod` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nue_sub` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nuevo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `xajaxdefault` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `autenticado` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `orden_programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `nue_programa`
--

INSERT INTO `nue_programa` (`id`, `cod_mod`, `cod_sub`, `programa`, `descripcion`, `f_ingreso`, `f_modifica`, `nota_prog`, `nue_mod`, `nue_sub`, `nuevo`, `xajaxdefault`, `autenticado`, `orden_programa`) VALUES
(1, '1', '1', 'INICIO', 'home', '7/07/2015', '7/07/2015', '', '1', '1', 'S', '', 'S', ''),
(2, '1', '1', 'LOGIN', 'inicio de sesion', '7/07/2015', '7/07/2015', '', '1', '1', 'S', '', 'N', ''),
(3, '1', '1', 'PROGRAMA', 'programas', '29/04/2014', '29/04/2014', '', '1', '1', 'S', '', 'S', ''),
(4, '1', '1', 'USUARIO', 'usuarios', '13/01/1995', '10/10/2015', '', '1', '1', 'S', '', 'S', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nue_programa01`
--

DROP TABLE IF EXISTS `nue_programa01`;
CREATE TABLE `nue_programa01` (
  `id` int(11) NOT NULL,
  `cod_mod` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cod_sub` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `opcion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nota_opc` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `menu` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `depende` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `vinculo` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `nue_programa01`
--

INSERT INTO `nue_programa01` (`id`, `cod_mod`, `cod_sub`, `programa`, `opcion`, `nota_opc`, `menu`, `depende`, `vinculo`) VALUES
(1, '1', '1', 'INICIO', 'A', 'Acceso', '', '', ''),
(2, '1', '1', 'PROGRAMA', 'A', 'Acceso', '', '', ''),
(3, '1', '1', 'USUARIO', 'A', 'Acceso', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permisos`
--

DROP TABLE IF EXISTS `permisos`;
CREATE TABLE `permisos` (
  `id` int(11) NOT NULL,
  `grupo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `opcion` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `permisos`
--

INSERT INTO `permisos` (`id`, `grupo`, `id_programa`, `opcion`) VALUES
(1, '1', '2', 'A'),
(2, '1', '3', 'A'),
(3, '1', '4', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `v_usuarios_permisos`
--

DROP TABLE IF EXISTS `v_usuarios_permisos`;
CREATE TABLE `v_usuarios_permisos` (
  `id` int(11) NOT NULL,
  `id_menu` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_menu_parent` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nombre_menu` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion_programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `icono` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `orden_menu` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `orden_programa` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `v_usuarios_permisos`
--

INSERT INTO `v_usuarios_permisos` (`id`, `id_menu`, `id_usuario`, `id_programa`, `id_menu_parent`, `programa`, `nombre_menu`, `descripcion_programa`, `icono`, `orden_menu`, `orden_programa`) VALUES
(1, '1', '1', '1', '0', 'PROGRAMA', 'prueba menu', ' Programas Core', 'fa-institution', '', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `core_permisos`
--
ALTER TABLE `core_permisos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `core_programas`
--
ALTER TABLE `core_programas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `core_programas_opciones`
--
ALTER TABLE `core_programas_opciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `core_roles`
--
ALTER TABLE `core_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `core_token`
--
ALTER TABLE `core_token`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `core_usuarios`
--
ALTER TABLE `core_usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `core_usuarios_roles`
--
ALTER TABLE `core_usuarios_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `grupos`
--
ALTER TABLE `grupos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `grupos_usuario`
--
ALTER TABLE `grupos_usuario`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modulo`
--
ALTER TABLE `modulo`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nue_programa`
--
ALTER TABLE `nue_programa`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nue_programa01`
--
ALTER TABLE `nue_programa01`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `permisos`
--
ALTER TABLE `permisos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `v_usuarios_permisos`
--
ALTER TABLE `v_usuarios_permisos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `core_permisos`
--
ALTER TABLE `core_permisos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `core_programas`
--
ALTER TABLE `core_programas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `core_programas_opciones`
--
ALTER TABLE `core_programas_opciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `core_roles`
--
ALTER TABLE `core_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `core_token`
--
ALTER TABLE `core_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `core_usuarios`
--
ALTER TABLE `core_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `core_usuarios_roles`
--
ALTER TABLE `core_usuarios_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `grupos`
--
ALTER TABLE `grupos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `grupos_usuario`
--
ALTER TABLE `grupos_usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `modulo`
--
ALTER TABLE `modulo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `nue_programa`
--
ALTER TABLE `nue_programa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `nue_programa01`
--
ALTER TABLE `nue_programa01`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `permisos`
--
ALTER TABLE `permisos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `v_usuarios_permisos`
--
ALTER TABLE `v_usuarios_permisos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
